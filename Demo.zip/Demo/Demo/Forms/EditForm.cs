﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    public partial class EditForm : Form
    {
        private int productId; // Идентификатор товара
        private DataBase db; // Экземпляр базы данных

        public EditForm(int id, DataBase database)
        {
            InitializeComponent();
            productId = id;
            db = database;
        }

        // Загрузка данных товара при открытии формы
        private void EditForm_Load(object sender, EventArgs e)
        {
            LoadProductData();
        }

        // Метод для загрузки данных товара по его Id
        private void LoadProductData()
        {
            string connectionString = "Data Source=DESKTOP-KG3VQL0;Initial Catalog=Magaz;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Товар WHERE Id_Товар = @productId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@productId", productId);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            // Заполнение полей формы данными товара
                            txtArticle.Text = reader["Артикул"].ToString();
                            txtName.Text = reader["Название"].ToString();
                            txtCategory.Text = reader["Категория"].ToString();
                            txtBrand.Text = reader["Бренд"].ToString();
                            txtAnimal.Text = reader["Животное"].ToString();
                            txtDescription.Text = reader["Описание"].ToString();
                            txtComposition.Text = reader["Состав"].ToString();
                            numQuantity.Value = Convert.ToInt32(reader["Количество"]);
                            txtUnit.Text = reader["Единица"].ToString();
                            numPrice.Value = Convert.ToDecimal(reader["Стоимость"]);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки данных товара: " + ex.Message);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Получаем данные из полей
            string article = txtArticle.Text;
            string name = txtName.Text;
            string category = txtCategory.Text;
            string brand = txtBrand.Text;
            string animal = txtAnimal.Text;
            string description = txtDescription.Text;
            string composition = txtComposition.Text;
            int quantity = (int)numQuantity.Value;
            string unit = txtUnit.Text;
            decimal price = numPrice.Value;

            // Обновляем товар в базе данных
            bool isUpdated = db.UpdateProduct(productId, article, name, category, brand, animal, description,
                                              composition, quantity, unit, price);

            if (isUpdated)
            {
                MessageBox.Show("Товар успешно отредактирован!");
                this.DialogResult = DialogResult.OK; // Закрываем форму с успешным результатом
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка редактирования товара.");
            }
        }
    }
}
