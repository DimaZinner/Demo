﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Demo
{
    public partial class AddForm : Form
    {
        private DataBase db;

        public AddForm()
        {
            InitializeComponent();
            db = new DataBase("Data Source=DESKTOP-KG3VQL0;Initial Catalog=Magaz;Integrated Security=True");
        }

        // Метод для добавления нового товара
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Получаем данные из текстовых полей
            string article = txtArticle.Text;
            string name = txtName.Text;
            string category = txtCategory.Text;
            string brand = txtBrand.Text;
            string animal = txtAnimal.Text;
            string description = txtDescription.Text;
            string composition = txtComposition.Text;
            int quantity = (int)numQuantity.Value;
            string unit = txtUnit.Text;
            decimal price = numPrice.Value;

            // Добавляем товар в базу данных через DataBase
            bool isSuccess = db.AddProduct(article, name, category, brand, animal, description, composition, quantity, unit, price);

            if (isSuccess)
            {
                MessageBox.Show("Товар успешно добавлен!");
                this.DialogResult = DialogResult.OK; // Возвращаем OK, чтобы закрыть форму
                this.Close(); // Закрываем форму
            }
            else
            {
                MessageBox.Show("Ошибка добавления товара.");
            }
        }
    }
}
